﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProShooter
{
    public partial class LuigiForm : Form
    {
        PoliceMan policeMan;
        PolicemanBoss policeBoss;
        Luigi luigi;
        Timer timerPoliceMan;
        Timer timerPolicemanBoss;
        Random random;
        PoliceManBossDoc docZB;
        PoliceManDoc doc;
        Timer movePoliceman;
        Timer movePB;
        Timer timerLuigi;
        Rectangle borders;
        Bullet bullet;
        BulletsDoc bulletsDoc;
        Timer bulletTimer;
        public LuigiForm()
        {
            InitializeComponent();
            DoubleBuffered = true;
            newDoc();
        }
        private void newDoc() {
            borders = new Rectangle(0, 0, Width, Height);
            doc = new PoliceManDoc();
            docZB = new PoliceManBossDoc();
            policeMan = null;
            policeBoss = null;
            random = new Random();
            luigi = new Luigi();
            luigi.Center = new Point(random.Next(15, Width / 4), random.Next(5, Height - 15));
            luigi.borders = borders;
            bullet = null;
            bulletsDoc = new BulletsDoc();
            timerPoliceMan = new Timer();
            timerPoliceMan.Interval = 3000;
            timerPoliceMan.Tick += new EventHandler(timerPoliceMan_Tick);
            timerPoliceMan.Start();
            timerPolicemanBoss = new Timer();
            timerPolicemanBoss.Interval = 6000;
            timerPolicemanBoss.Tick += new EventHandler(timerPolicemanBoss_Tick);
            timerPolicemanBoss.Start();
            movePoliceman = new Timer();
            movePoliceman.Interval = 150;
            movePoliceman.Tick += new EventHandler(movePoliceman_Tick);
            movePoliceman.Start();
            movePB = new Timer();
            movePB.Interval = 150;
            movePB.Tick += new EventHandler(movePB_Tick);
            movePB.Start();
            timerLuigi = new Timer();
            timerLuigi.Interval = 100;
            timerLuigi.Tick += new EventHandler(timerLuigi_Tick);

            timerLuigi.Start();
            bulletTimer = new Timer();
            bulletTimer.Interval = 100;
            bulletTimer.Tick += new EventHandler(bulletTimer_Tick);
            bulletTimer.Start();


        }
        private void bulletTimer_Tick(object sender, EventArgs e)
        {
            bulletsDoc.Move();
            foreach (PoliceMan z in doc.PoliceManList)
            {
                bulletsDoc.CheckCollisions(z.Center);


            }
            foreach (PolicemanBoss z in docZB.policeBosses)
            {
                bulletsDoc.CheckCollisions(z.Center);


            }

            bulletsDoc.Delete();
            Invalidate(true);
        }
        private void timerLuigi_Tick(object sender, EventArgs e)
        {
            if (luigi.power <= 20)
            {
                pictureBox1.Image = Properties.Resources._3lives;
            }
            if (luigi.power <= 13)
            {
                pictureBox1.Image = Properties.Resources._2lives;
            }
            if (luigi.power <= 6)
            {
                pictureBox1.Image = Properties.Resources._1life;
            }
            if (luigi.power <= 0)
            {
                pictureBox1.Image = null;
            }


            foreach (PoliceMan z in doc.PoliceManList)
            {
                if (luigi.HasColided(z.Center))
                {
                    luigi.power -= z.power;
                }

            }
            foreach (PolicemanBoss z in docZB.policeBosses)
            {
                if (luigi.HasColided(z.Center))
                {
                    luigi.power = 0;
                }
            }
            if (luigi.PowerZero() == true)
            {
                Application.Exit();
            }
            Invalidate(true);
        }
        private void AskNewGame()
        {
            int score = doc.totalKills + docZB.totalKills;
            DialogResult dialog = MessageBox.Show("Luigi is dead. Your score is: "+score.ToString(), "The game is over", MessageBoxButtons.OK, MessageBoxIcon.Information);
            if (dialog == DialogResult.Yes)
            {
                newDoc();
            }
            if (dialog == DialogResult.No)
            {
                Application.Exit();
            }
        }
        private void timerPoliceMan_Tick(object sender, EventArgs e)
        {
            policeMan = new PoliceMan();
            policeMan.Center = new Point(random.Next(Width - 100, Width - 20), random.Next(30, Height - 30));
            policeMan.borders = borders;
            doc.AddPoliceman(policeMan);
            Invalidate(true);
        }
        private void timerPolicemanBoss_Tick(object sender, EventArgs e)
        {
            policeBoss = new PolicemanBoss();
            policeBoss.Center = new Point(random.Next(Width - 100, Width - 20), random.Next(30, Height - 30));
            docZB.AddPoliceBoss(policeBoss);
            Invalidate(true);
        }
        private void movePoliceman_Tick(object sender, EventArgs e)
        {
            doc.Move();
            doc.CheckCrosses();
            doc.CheckColisions(luigi.Center);
            foreach (Bullet b in bulletsDoc.Bullets)
            {
                doc.CheckCollisionsWithBullets(b.Center, luigi.damage);
            }
            doc.DeleteZombie();
            Invalidate(true);
        }

        public void movePB_Tick(object sender, EventArgs e)
        {
            docZB.Move(luigi.Center);
            docZB.IncreasePower();
            foreach (Bullet b in bulletsDoc.Bullets)
            {
                docZB.CheckCollisonsWithBullets(b.Center, luigi.damage);
            }
            docZB.PowerZero();
            docZB.Delete();
            Invalidate(true);

        }

        private void LuigiForm_Paint(object sender, PaintEventArgs e)
        {
            luigi.Draw(e.Graphics);
            if (policeMan != null)
            {
                policeMan.Draw(e.Graphics);
            }
            if (policeBoss != null)
            {
                policeBoss.Draw(e.Graphics);
            }
            if (bullet != null)
            {
                bullet.Draw(e.Graphics);
            }
            bulletsDoc.Draw(e.Graphics);
            doc.Draw(e.Graphics);
            docZB.Draw(e.Graphics);
        }

        private void LuigiForm_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.W || e.KeyCode == Keys.Up)
            {
                luigi.direction = Luigi.TYPE.Up;
               luigi.Move();

            }
            if (e.KeyCode == Keys.S || e.KeyCode == Keys.Down)
            {
                luigi.direction = Luigi.TYPE.Down;
                luigi.Move();
            }
            if (e.KeyCode == Keys.A || e.KeyCode == Keys.Left)
            {
                luigi.direction = Luigi.TYPE.Left;
                luigi.Move();
            }
            if (e.KeyCode == Keys.D || e.KeyCode == Keys.Right)
            {
                luigi.direction = Luigi.TYPE.Right;
                luigi.Move();
            }
            if (e.KeyCode == Keys.Space)
            {
                bullet = new Bullet();
                if (luigi.direction == Luigi.TYPE.Left)
                {
                    bullet.direction = Bullet.TYPE.Right;
                }
                if (luigi.direction == Luigi.TYPE.Right)
                {
                    bullet.direction = Bullet.TYPE.Right;
                }
                if (luigi.direction == Luigi.TYPE.Up)
                {
                    bullet.direction = Bullet.TYPE.Right;
                }
                if (luigi.direction == Luigi.TYPE.Down)
                {
                    bullet.direction = Bullet.TYPE.Right;
                }
                bullet.Center = luigi.Center;
                bullet.borders = borders;
                bulletsDoc.AddBullet(bullet);
            }
            Invalidate(true);
        }

        private void LuigiForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            AskNewGame();
            Invalidate(true);
        }

        private void LuigiForm_Resize(object sender, EventArgs e)
        {
            borders = new Rectangle(0, 0, Width, Height);
            foreach (Bullet b in bulletsDoc.Bullets)
            {
                b.borders = borders;
            }
            foreach (PoliceMan z in doc.PoliceManList)
            {
                z.borders = borders;
            }
            luigi.borders = borders;
            Invalidate(true);
        }

        private void statusStrip1_Paint(object sender, PaintEventArgs e)
        {
            int score = doc.totalKills + docZB.totalKills;
            int force = doc.PoliceManList.Count + docZB.policeBosses.Count;
            toolStripStatusLabel1.Text = "Score: " + score.ToString() + ". Police force: " + force.ToString();
        }

       
    }
}
