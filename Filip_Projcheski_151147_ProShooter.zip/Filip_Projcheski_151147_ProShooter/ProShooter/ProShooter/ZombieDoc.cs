﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProShooter
{
    public class ZombieDoc
    {
        public List<Zombie> zombieList { get; set; }
        public int globalCrossesCounter { get; set; }
        public int totalKills { get; set; }
        public int globalZombiePower { get; set; }
        public ZombieDoc() {
            zombieList = new List<Zombie>();
            globalCrossesCounter = 0;
            totalKills = 0;

        }

        public void AddZombie(Zombie z) {
            zombieList.Add(z);

        }
        public void Draw(Graphics g) {

            foreach (Zombie z in zombieList) {
                z.Draw(g);
            }
        }
        public void Move()
        {

            foreach (Zombie z in zombieList)
            {
                z.Move();
            }
        }

        public void CheckCrosses() {
            foreach (Zombie z in zombieList) {
                globalCrossesCounter += z.countCrosses;
            }
        }

        public void CheckColisions(Point p) {
            foreach (Zombie z in zombieList) {
                if (z.HasColided(p) == true) {
                    globalZombiePower += z.power;
                    z.power = 0;
                    z.isDead = true;
                }
            }
           

        }
        public void CheckCollisionsWithBullets(Point p,int damage) {
            foreach (Zombie z in zombieList)
            {
                if (z.HasColided(p) == true)
                {
                   
                    z.power -=damage;
                    if (z.power <= 0)
                    {
                        totalKills++;
                        z.isDead = true;
                    }
                }
            }
        }

        public void DeleteZombie() {
            for (int i = zombieList.Count - 1; i >= 0; i--) {
                if (zombieList[i].isDead == true) {
                    zombieList.RemoveAt(i);
                }

            }

        }


    }
}
