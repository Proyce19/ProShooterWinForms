﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProShooter
{
    public class Bullet
    {
        public Point Center { get; set; }
        public int width { get; set; }
        public int height { get; set; }
        public bool isDead { get; set; }
        public enum TYPE { Up,Down,Left,Right}
        public TYPE direction { get; set; }
        public Rectangle borders { get; set; }
        public int speed { get; set; }
        public Image Look { get; set; }
        public Bullet() {
            width = 6;
            height = 9;
            isDead = false;
            speed = 10;
        }
        public void Move()
        {
            if (direction == TYPE.Left)
            {
                if (Center.X + width / 2 > borders.Left)
                {
                    Center = new Point(Center.X - speed, Center.Y);

                }
                else
                {
                    isDead = true;
                }

            }
            if (direction == TYPE.Right)
            {
                if (Center.X + width / 2 < borders.Right)
                {
                    Center = new Point(Center.X + speed, Center.Y);

                }
                else
                {
                    isDead = true;
                }

            }
            if (direction == TYPE.Up)
            {
                if (Center.Y + height / 2 > borders.Top)
                {
                    Center = new Point(Center.X, Center.Y - speed);

                }
                else
                {
                    isDead = true;
                }

            }
            if (direction == TYPE.Down)
            {
                if (Center.Y + height / 2 < borders.Bottom)
                {
                    Center = new Point(Center.X, Center.Y + speed);

                }
                else
                {
                    isDead = true;
                }

            }

        }



        public void Draw(Graphics g)
        {
            if (direction == TYPE.Right)
            {
                Look = Properties.Resources.bulletRight;
                g.DrawImage(Look, Center);
            }
            if (direction == TYPE.Left)
            {
                Look = Properties.Resources.bulletLeft;
                g.DrawImage(Look, Center);
            }
            if (direction == TYPE.Down)
            {
                Look = Properties.Resources.bulletDown;
                g.DrawImage(Look, Center);
            }
            if (direction == TYPE.Up)
            {
                Look = Properties.Resources.bulletUp;
                g.DrawImage(Look, Center);
            }


        }

        public bool HasColided(Point p)
        {
            return ((Center.X - p.X) * (Center.X - p.X) + (Center.Y - p.Y) * (Center.Y - p.Y)) <= ((width+20) * (height+20));

        }



    }
}
