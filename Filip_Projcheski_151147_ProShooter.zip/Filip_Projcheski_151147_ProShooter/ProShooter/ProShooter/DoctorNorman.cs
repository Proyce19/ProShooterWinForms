﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProShooter
{
    public class DoctorNorman
    {

        public Point Center { get; set; }
        public int width { get; set; }
        public int height { get; set; }
        public bool isDead { get; set; }
        public int power { get; set; }
        public int damage { get; set; }

        public int speed { get; set; }
        public int zombiesKilled { get; set; }
        public enum TYPE { Up,Down,Left,Right }
        public Rectangle borders { get; set; }
        public TYPE direction { get; set; }
        public Image Look { get; set; }
        public DoctorNorman() {
            width = 24;
            height = 48;
            isDead = false;
            power = 15;
            damage = 10;
            speed = 5;
            zombiesKilled = 0;
            Look = Properties.Resources.scientist;
            


        }

        public void Move() {
            if (direction == TYPE.Left) {
                if (Center.X + width / 2 > borders.Left) {
                    Center = new Point(Center.X - speed, Center.Y);

                }

            }
            if (direction == TYPE.Right)
            {
                if (Center.X + width / 2 < borders.Right)
                {
                    Center = new Point(Center.X + speed, Center.Y);

                }

            }
            if (direction == TYPE.Up)
            {
                if (Center.Y + height/ 2 > borders.Top)
                {
                    Center = new Point(Center.X, Center.Y-speed);

                }

            }
            if (direction == TYPE.Down)
            {
                if (Center.Y + height / 2 < borders.Bottom)
                {
                    Center = new Point(Center.X, Center.Y+speed);

                }

            }

        }



        public void Draw(Graphics g) {
            g.DrawImage(Look, Center);


        }

        public bool HasColided(Point p) {
            return ((Center.X - p.X) * (Center.X - p.X) + (Center.Y - p.Y) * (Center.Y - p.Y)) <= width * height;

        }

        public bool PowerZero() {
            return power <= 0;
        }
       
    }
}
