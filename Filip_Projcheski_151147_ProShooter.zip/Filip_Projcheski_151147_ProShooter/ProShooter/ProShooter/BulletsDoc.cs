﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProShooter
{
    public class BulletsDoc
    {
        public List<Bullet> Bullets { get; set; }
        public BulletsDoc() {
            Bullets = new List<Bullet>();
        }
        public void AddBullet(Bullet b) {
            Bullets.Add(b);
        }
        public void Move() {
            foreach (Bullet b in Bullets) {
                b.Move();
            }
        }
        public void Draw(Graphics g) {
            foreach (Bullet b in Bullets) {
                b.Draw(g);
            }

        }
        public void CheckCollisions(Point p) {
            foreach (Bullet b in Bullets)
            {
                if (b.HasColided(p) == true) {
                    b.isDead = true;
                }
            }

        }
        public void Delete() {
            for (int i = Bullets.Count - 1; i >= 0; i--) {
                if (Bullets[i].isDead == true) {
                    Bullets.RemoveAt(i);
                }
            }

        }


    }
}
