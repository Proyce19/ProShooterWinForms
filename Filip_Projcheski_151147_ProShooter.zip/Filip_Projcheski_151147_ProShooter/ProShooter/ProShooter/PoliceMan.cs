﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProShooter
{
    public class PoliceMan
    {
        public Point Center { get; set; }
        public int width { get; set; }
        public int height { get; set; }
        public bool isDead { get; set; }
        public int power { get; set; }
        public int damage { get; set; }

        public int speed { get; set; }
        public int countCrosses { get; set; }
        public enum TYPE { Up, Down, Left, Right }
        public Rectangle borders { get; set; }
        public TYPE direction { get; set; }
        public Image Look { get; set; }

        public PoliceMan()
        {
            width = 24;
            height = 48;
            damage = 4;
            power = 7;
            speed = 3;
            countCrosses = 0;
            direction = TYPE.Left;
            Look = Properties.Resources.policeman;
            isDead = false;




        }

        public void Move()
        {

            if (direction == TYPE.Left)
            {
                if (Center.X + width / 2 > borders.Left)
                {
                    Center = new Point(Center.X - speed, Center.Y);

                }
                else
                {
                    countCrosses++;
                    isDead = true;

                }

            }


        }



        public void Draw(Graphics g)
        {
            g.DrawImage(Look, Center);


        }

        public bool HasColided(Point p)
        {
            return ((Center.X - p.X) * (Center.X - p.X) + (Center.Y - p.Y) * (Center.Y - p.Y)) <= width * height;

        }



    }
}
