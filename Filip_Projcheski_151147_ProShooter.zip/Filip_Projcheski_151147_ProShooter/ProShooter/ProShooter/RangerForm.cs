﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProShooter
{
    public partial class RangerForm : Form
    {
        Wolf wolf;
        Lion lion;
        Ranger ranger;
        Timer timerWolf;
        Timer timerLion;
        Random random;
        LionsDoc docZB;
        WolfsDoc doc;
        Timer moveWolf;
        Timer moveLion;
        Timer timerRanger;
        Rectangle borders;
        Bullet bullet;
        BulletsDoc bulletsDoc;
        Timer bulletTimer;
        public RangerForm()
        {
            InitializeComponent();
            DoubleBuffered = true;
            newDoc();
        }
        private void newDoc() {
            borders = new Rectangle(0, 0, Width, Height);
            doc = new WolfsDoc();
            docZB = new LionsDoc();
            wolf = null;
            lion = null;
            random = new Random();
            ranger  = new Ranger();
            ranger.Center = new Point(random.Next(15, Width / 4), random.Next(5, Height - 15));
            ranger.borders = borders;
            bullet = null;
            bulletsDoc = new BulletsDoc();
            timerWolf = new Timer();
            timerWolf.Interval = 3000;
            timerWolf.Tick += new EventHandler(timerWolf_Tick);
            timerWolf.Start();
            timerLion = new Timer();
            timerLion.Interval = 6000;
            timerLion.Tick += new EventHandler(timerLion_Tick);
            timerLion.Start();
            moveWolf = new Timer();
            moveWolf.Interval = 150;
            moveWolf.Tick += new EventHandler(moveWolf_Tick);
            moveWolf.Start();
            moveLion = new Timer();
            moveLion.Interval = 150;
            moveLion.Tick += new EventHandler(moveLion_Tick);
            moveLion.Start();
            timerRanger = new Timer();
            timerRanger.Interval = 100;
            timerRanger.Tick += new EventHandler(timerRanger_Tick);

            timerRanger.Start();
            bulletTimer = new Timer();
            bulletTimer.Interval = 100;
            bulletTimer.Tick += new EventHandler(bulletTimer_Tick);
            bulletTimer.Start();

    }

        private void bulletTimer_Tick(object sender, EventArgs e)
        {
            bulletsDoc.Move();
            foreach (Wolf z in doc.wolfsList)
            {
                bulletsDoc.CheckCollisions(z.Center);


            }
            foreach (Lion z in docZB.lionsList)
            {
                bulletsDoc.CheckCollisions(z.Center);


            }

            bulletsDoc.Delete();
            Invalidate(true);
        }
        private void timerRanger_Tick(object sender, EventArgs e)
        {
            if (ranger.power <= 25)
            {
                pictureBox1.Image = Properties.Resources._3lives;
            }
            if (ranger.power <= 15)
            {
                pictureBox1.Image = Properties.Resources._2lives;
            }
            if (ranger.power <= 7)
            {
                pictureBox1.Image = Properties.Resources._1life;
            }
            if (ranger.power <= 0)
            {
                pictureBox1.Image = null;
            }
            foreach (Wolf z in doc.wolfsList)
            {
                if (ranger.HasColided(z.Center))
                {
                    ranger.power -= z.power;
                }

            }
            foreach (Lion z in docZB.lionsList)
            {
                if (ranger.HasColided(z.Center))
                {
                    ranger.power = 0;
                }
            }
            if (ranger.PowerZero() == true)
            {
                Application.Exit();
            }
            Invalidate(true);
        }
        private void AskNewGame()
        {
            int score = doc.totalKills + docZB.totalKills;
            DialogResult dialog = MessageBox.Show("Jackson the Ranger is dead. Your score is: " + score.ToString(), "The game is over", MessageBoxButtons.OK, MessageBoxIcon.Information);
            if (dialog == DialogResult.Yes)
            {
                newDoc();
            }
            if (dialog == DialogResult.No)
            {
                Application.Exit();
            }
        }
        private void timerWolf_Tick(object sender, EventArgs e)
        {
            wolf = new Wolf();
            wolf.Center = new Point(random.Next(Width - 100, Width - 20), random.Next(30, Height - 30));
            wolf.borders = borders;
            doc.AddWolf(wolf);
            Invalidate(true);
        }
        private void timerLion_Tick(object sender, EventArgs e)
        {
            lion = new Lion();
            lion.Center = new Point(random.Next(Width - 100, Width - 20), random.Next(30, Height - 30));
            docZB.AddLion(lion);
            Invalidate(true);
        }
        private void moveWolf_Tick(object sender, EventArgs e)
        {
            doc.Move();
            doc.CheckCrosses();
            doc.CheckColisions(ranger.Center);
            foreach (Bullet b in bulletsDoc.Bullets)
            {
                doc.CheckCollisionsWithBullets(b.Center, ranger.damage);
            }
            doc.DeleteZombie();
            Invalidate(true);
        }

        public void moveLion_Tick(object sender, EventArgs e)
        {
            docZB.Move(ranger.Center);
            docZB.IncreasePower();
            foreach (Bullet b in bulletsDoc.Bullets)
            {
                docZB.CheckCollisonsWithBullets(b.Center, ranger.damage);
            }
            docZB.PowerZero();
            docZB.Delete();
            Invalidate(true);

        }

        private void RangerForm_Paint(object sender, PaintEventArgs e)
        {
           ranger.Draw(e.Graphics);
            if (wolf != null)
            {
                wolf.Draw(e.Graphics);
            }
            if (lion != null)
            {
                lion.Draw(e.Graphics);
            }
            if (bullet != null)
            {
                bullet.Draw(e.Graphics);
            }
            bulletsDoc.Draw(e.Graphics);
            doc.Draw(e.Graphics);
            docZB.Draw(e.Graphics);
        }

        private void RangerForm_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.W || e.KeyCode == Keys.Up)
            {
                ranger.direction = Ranger.TYPE.Up;
                ranger.Move();

            }
            if (e.KeyCode == Keys.S || e.KeyCode == Keys.Down)
            {
                ranger.direction = Ranger.TYPE.Down;
                ranger.Move();
            }
            if (e.KeyCode == Keys.A || e.KeyCode == Keys.Left)
            {
                ranger.direction = Ranger.TYPE.Left;
                ranger.Move();
            }
            if (e.KeyCode == Keys.D || e.KeyCode == Keys.Right)
            {
                ranger.direction = Ranger.TYPE.Right;
                ranger.Move();
            }
            if (e.KeyCode == Keys.Space)
            {
                bullet = new Bullet();
                if (ranger.direction == Ranger.TYPE.Left)
                {
                    bullet.direction = Bullet.TYPE.Right;
                }
                if (ranger.direction == Ranger.TYPE.Right)
                {
                    bullet.direction = Bullet.TYPE.Right;
                }
                if (ranger.direction == Ranger.TYPE.Up)
                {
                    bullet.direction = Bullet.TYPE.Right;
                }
                if (ranger.direction == Ranger.TYPE.Down)
                {
                    bullet.direction = Bullet.TYPE.Right;
                }
                bullet.Center = ranger.Center;
                bullet.borders = borders;
                bulletsDoc.AddBullet(bullet);
            }
            Invalidate(true);
        }

        private void RangerForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            AskNewGame();
            Invalidate(true);
        }

        private void RangerForm_Resize(object sender, EventArgs e)
        {
            borders = new Rectangle(0, 0, Width, Height);
            foreach (Bullet b in bulletsDoc.Bullets)
            {
                b.borders = borders;
            }
            foreach (Wolf z in doc.wolfsList)
            {
                z.borders = borders;
            }
            ranger.borders = borders;
            Invalidate(true);
        }

        private void statusStrip1_Paint(object sender, PaintEventArgs e)
        {
            int score = doc.totalKills + docZB.totalKills;
            int force = doc.wolfsList.Count + docZB.lionsList.Count;
            toolStripStatusLabel1.Text = "Score: " + score.ToString() + ". Animals: " + force.ToString();
        }

       
    }

}
