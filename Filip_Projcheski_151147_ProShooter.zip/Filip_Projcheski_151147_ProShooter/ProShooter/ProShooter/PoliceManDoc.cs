﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProShooter
{
    public class PoliceManDoc
    {
        public int totalKills { get; set; }
        public List<PoliceMan> PoliceManList { get; set; }
        public int globalCrossesCounter { get; set; }
        public int globalPolicePower { get; set; }
        public PoliceManDoc()
        {
            PoliceManList = new List<PoliceMan>();
            globalCrossesCounter = 0;
            globalPolicePower = 0;
            totalKills = 0;


        }

        public void AddPoliceman(PoliceMan z)
        {
            PoliceManList.Add(z);

        }
        public void Draw(Graphics g)
        {

            foreach (PoliceMan z in PoliceManList)
            {
                z.Draw(g);
            }
        }
        public void Move()
        {

            foreach (PoliceMan z in PoliceManList)
            {
                z.Move();
            }
        }

        public void CheckCrosses()
        {
            foreach (PoliceMan z in PoliceManList)
            {
                globalCrossesCounter += z.countCrosses;
            }
        }

        public void CheckColisions(Point p)
        {
            foreach (PoliceMan z in PoliceManList)
            {
                if (z.HasColided(p) == true)
                {
                    globalPolicePower += z.power;
                    z.power = 0;
                    z.isDead = true;
                }
            }


        }
        public void CheckCollisionsWithBullets(Point p, int damage)
        {
            foreach (PoliceMan z in PoliceManList)
            {
                if (z.HasColided(p) == true)
                {

                    z.power -= damage;
                    if (z.power <= 0)
                    {
                        totalKills++;
                        z.isDead = true;
                    }
                }
            }
        }

        public void DeleteZombie()
        {
            for (int i = PoliceManList.Count - 1; i >= 0; i--)
            {
                if (PoliceManList[i].isDead == true)
                {
                    PoliceManList.RemoveAt(i);
                }

            }

        }


    }
}
